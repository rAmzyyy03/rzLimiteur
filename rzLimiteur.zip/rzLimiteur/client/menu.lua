local limitMenu = RageUI.CreateMenu("Menu Vitesse", "Limiteur de vitesse")
limitMenu.Closed = function()
    open = false
    RageUI.Visible(limitMenu, false)
end

local kmValue = {
    "15",
    "30",
    "45",
    "60",
    "90",
}

function OpenLimitateurMenu()
    if open then
        open = false
        RageUI.Visible(limitMenu, false)
    else
        open = true
        RageUI.Visible(limitMenu, true)
        Citizen.CreateThread(function()
            while open do
                Wait(1)
                RageUI.IsVisible(limitMenu, function()
                    RageUI.Button("~b~Autre Vitesse~b~", description, {}, true, {
                        onSelected = function()
                            local vitesseVroumVroum = KeyBoardInput('Veuillez indiqué la vitesse que vous souhaitez : ', '', 3, false)
                                if vitesseVroumVroum == nil then
                                    print('La valeur indiquée est incorrecte !')
                                else
                                vitesse(vitesseVroumVroum)
                                end
                        end
                    })
                    RageUI.Button("~r~Retirer la limite~b~", description, {}, true, {
                        onSelected = function()
                                vitesse(0)
                        end
                    })
                    for k, value in pairs(kmValue) do
                        RageUI.Button(value.." Km/h", description, {}, true, {
                            onSelected = function()
                                vitesse(value)
                            end
                        })
                    end
                end)
            end
        end)
    end
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		
		if IsPedInAnyVehicle(PlayerPedId()) then
			if IsControlJustPressed(0, 101) then
                OpenLimitateurMenu()
			end
		end
	end
end)
